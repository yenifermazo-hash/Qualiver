"""
Genera el PDF del documento de ajustes Qualiver a partir del HTML.

Uso:
    python generar_pdf.py ruta/ajustes.html
    python generar_pdf.py ruta/ajustes.html --nombre "Ajustes a <aplicación> - <fechas>"

Intenta primero con Playwright (pip install playwright && playwright install chromium).
Si no está, usa Chrome o Edge instalados en el computador.
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


def con_playwright(html: Path, pdf: Path) -> bool:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return False
    with sync_playwright() as p:
        navegador = p.chromium.launch()
        pagina = navegador.new_page()
        pagina.goto(html.resolve().as_uri())
        pagina.wait_for_load_state("networkidle")
        pagina.pdf(path=str(pdf), format="Letter", print_background=True,
                   prefer_css_page_size=True,
                   margin={"top": "16mm", "bottom": "16mm", "left": "15mm", "right": "15mm"})
        navegador.close()
    return True


def buscar_navegador():
    candidatos = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    ]
    for c in candidatos:
        if os.path.exists(c):
            return c
    for nombre in ("google-chrome", "chromium", "chromium-browser", "msedge", "chrome"):
        ruta = shutil.which(nombre)
        if ruta:
            return ruta
    return None


def con_chrome(html: Path, pdf: Path) -> bool:
    navegador = buscar_navegador()
    if not navegador:
        return False
    subprocess.run([
        navegador, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        f"--print-to-pdf={pdf.resolve()}", html.resolve().as_uri(),
    ], check=True)
    return pdf.exists()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("html")
    parser.add_argument("--nombre", help="Nombre del PDF sin la extensión")
    args = parser.parse_args()

    html = Path(args.html)
    if not html.exists():
        sys.exit(f"No encuentro el archivo: {html}")

    texto = html.read_text(encoding="utf-8")
    if "{{" in texto:
        print("OJO: todavía quedan espacios {{ }} sin llenar en el HTML.")

    nombre = args.nombre or html.stem
    pdf = html.with_name(f"{nombre}.pdf")

    if con_playwright(html, pdf) or con_chrome(html, pdf):
        print(f"PDF listo: {pdf.resolve()}")
    else:
        sys.exit("No encontré Playwright ni Chrome/Edge. Instale uno: "
                 "pip install playwright && playwright install chromium")


if __name__ == "__main__":
    main()
