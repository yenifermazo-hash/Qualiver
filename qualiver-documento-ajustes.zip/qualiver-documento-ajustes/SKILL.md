---
name: qualiver-documento-ajustes
description: Arma el documento de ajustes que Qualiver le envía a un cliente (PDF), siempre con el mismo diseño. Úsala cuando pidan "el documento de ajustes", "documentar los cambios para el cliente", "informe de lo que se hizo", "notas de entrega" o algo parecido.
---

# Documento de ajustes Qualiver

Esta skill produce **un solo tipo de documento**: el PDF que Qualiver le envía a un cliente para contarle qué ajustes se hicieron en su aplicación. Sirve para cualquier cliente y cualquier tipo de aplicación (AppSheet, página web, tablero, automatización, etc.).

Todos los documentos deben verse **idénticos** en diseño. Lo único que cambia es el contenido. Nunca inventes un diseño nuevo, nunca cambies colores, letras ni estructura: siempre copia `plantilla/plantilla.html` y llénala.

Todo el contenido sale **de lo que la persona te cuenta y de lo que encuentres en el proyecto actual**. Nunca uses textos, nombres ni imágenes de otros clientes o documentos anteriores.

---

## Regla de oro: primero preguntar, después escribir

No escribas el documento con suposiciones. **Pregunta, indaga y confirma** antes de armarlo. Haz las preguntas **por partes** (no todas de una vez) y espera la respuesta antes de seguir.

### Paso 0 — Indagar en el proyecto

Antes de preguntar, revisa lo que ya hay para llegar con una propuesta:

- Si es un repositorio: los cambios recientes (`git log`, `git diff`) de las fechas que te digan.
- `CLAUDE.md`, PRD, README o notas del proyecto.
- Documentos de ajustes anteriores **de este mismo proyecto** en `docs/ajustes/`, solo para seguir la numeración y no repetir cambios ya entregados.

Con eso arma un **borrador de lista de cambios** y muéstraselo a la persona para que lo corrija. Si no hay nada que revisar, pasa directo al Paso 1.

### Paso 1 — Datos generales

Pregunta y espera respuesta:

1. ¿Para qué cliente es y cómo se llama la aplicación? (va en el título)
2. ¿De qué fecha o fechas son los cambios?
3. ¿Dónde los revisa el cliente? (enlace, ambiente de pruebas o el real, con qué usuario o rol)
4. ¿Tiene que hacer algo antes de ver los cambios? (recargar la página, cerrar sesión, sincronizar la app…)

### Paso 2 — Qué se hizo, cambio por cambio

Muestra la lista de cambios que encontraste (Paso 0) y pregunta:

- ¿Está completa? ¿Falta algo? ¿Sobra algo?
- ¿En qué orden van? (lo más importante primero)

Luego, **por cada cambio**, pregunta lo que falte de esto:

- **Qué es**, en una frase que entienda el cliente.
- **Dónde está**: la ruta exacta en pantalla, con flechas (`Menú → Sección → Opción`).
- **Quién lo ve**: qué tipo de usuario.
- **Cómo funciona**: lo que el cliente necesita saber para usarlo.
- **Un ejemplo**, si ayuda a entenderlo.

### Paso 3 — Imágenes (siempre preguntar)

Por cada cambio pregunta:

- «¿Tienes captura de pantalla de esto? Pásame la ruta del archivo o pégala en la carpeta `imagenes/` del documento».
- «¿Qué quieres que diga el pie de la foto?» (una frase corta que explique qué se ve).

Si no hay foto para un cambio, pregunta si se deja sin imagen. En el documento final **nunca** quedan imágenes inventadas, de otros proyectos, ni cuadros vacíos.

### Paso 4 — Lo que se quitó y otros ajustes

Pregunta:

- ¿Se quitó algo que el cliente usaba antes? ¿Qué lo reemplaza? ¿Qué pasa con la información que ya estaba guardada?
- ¿Hubo ajustes pequeños (textos, colores, estilos) que valga la pena mencionar?

### Paso 5 — Guía paso a paso (opcional)

Pregunta: «¿Quieres agregar al final una guía paso a paso para que el cliente aprenda a usar algo?». Si dice que sí, pregunta de qué tema y arma los pasos con letras (A, B, C…).

### Paso 6 — Confirmar antes de armar

Muestra un resumen corto de lo que va a llevar el documento (título, cuántos cambios, qué fotos van) y pregunta «¿Lo armo así?». Solo con un sí, sigue.

---

## Cómo se escribe (tono)

- Se le habla al cliente de **usted**.
- Lenguaje sencillo. Nada de palabras técnicas (base de datos, tabla, columna, código, servidor, error de programación…). Se explica lo que la persona **ve y hace** en pantalla.
- Frases cortas. Viñetas antes que párrafos largos.
- Nombres de botones, pestañas y opciones en **negrilla**, y entre comillas latinas «» cuando es el texto exacto del botón.
- Rutas con flecha `→`, dentro de `<span class="ruta">`.
- Si algo todavía no está listo, se escribe **Pendiente:** y qué falta.
- Fechas en español: «día de mes de año».

---

## Estructura fija del documento (no cambiar el orden)

1. **Título**: `Ajustes a <nombre de la aplicación> · <fechas>`
2. **Recuadro de entrada** (naranja claro): dónde revisarlos, qué hacer antes, de qué partes se compone el documento.
3. **Lo nuevo del <fechas>** → **Resumen**: tabla `#` / `Qué hay de nuevo` / `Dónde`. Una fila por cambio. La última fila es «Lo que se quitó» si aplica.
4. **Una sección numerada por cambio** (círculo naranja con el número + título), con:
   - Línea **Dónde:** con la ruta.
   - Viñetas con la explicación.
   - Tabla, si hay varias opciones que comparar (opcional).
   - Ejemplo (opcional).
   - Captura con su pie de foto (si hay).
5. **Lo que se quitó** (con recuadro rojo para lo más importante). Solo si aplica.
6. **Otros ajustes**. Solo si aplica.
7. **Guía paso a paso** con secciones A, B, C… Solo si la piden.
8. **Pie**: `<nombre de la aplicación> · <cliente> · Ajustes del <fechas>.`

Si una parte no aplica, **se quita entera** (no se deja vacía ni con «N/A»).

---

## Cómo armar el archivo

1. Crea la carpeta `docs/ajustes/AAAA-MM-DD-<cliente>/` en el proyecto (fecha del último día de cambios).
2. Copia ahí `plantilla/plantilla.html` como `ajustes.html` y crea la subcarpeta `imagenes/`.
3. Copia las capturas que te dieron a `imagenes/` con nombres simples: `01-<tema>.png`, `02-<tema>.png`…
4. Llena `ajustes.html`:
   - Reemplaza todo lo que está entre `{{ }}`.
   - Duplica los bloques marcados REPETIR las veces que haga falta.
   - Borra los bloques marcados OPCIONAL que no apliquen.
   - Cambia cada `<div class="captura-vacia">…</div>` por `<img src="imagenes/<archivo>.png" alt="">`, o borra el `<figure>` completo si ese cambio no lleva foto.
   - **No toques** la parte `<style>`.
5. Genera el PDF (el script está en la carpeta de esta skill):
   ```
   python scripts/generar_pdf.py docs/ajustes/AAAA-MM-DD-<cliente>/ajustes.html --nombre "Ajustes a <nombre> - <fechas>"
   ```
   Usa Playwright si está instalado; si no, usa Chrome o Edge del computador.
6. **Revisa el PDF** antes de entregarlo: que no quede ningún `{{ }}` ni `captura-vacia`, que las fotos carguen y que nada quede partido feo entre páginas.
7. Dile a la persona dónde quedó el PDF y pregúntale si quiere cambiar algo.

---

## Lista de chequeo final

- [ ] No queda ningún `{{` ni `captura-vacia` en el HTML.
- [ ] El número de filas del Resumen coincide con el número de secciones numeradas.
- [ ] Cada sección tiene su línea **Dónde:**.
- [ ] Todas las imágenes son de este proyecto, existen y tienen pie de foto.
- [ ] No hay palabras técnicas.
- [ ] La parte `<style>` está igual a la de la plantilla.
